#ifndef MARKET_RISK_HPP
#define MARKET_RISK_HPP
#include <vector>
#include <string>

namespace MarketRisk {
struct LiquidityInput {
    double bid;
    double ask;
    double marketDepth;
    double requiredAmount;
};
struct RiskResult {
    double volatilityPercent;
    double liquidityScore;
    double riskPenaltyPercent;
    double riskAdjustedReturnPercent;
    std::string decision;
};
double calculateVolatility(const std::vector<double>& rates);
double calculateSpreadPercent(double bid, double ask);
double calculateLiquidityScore(const LiquidityInput& input);
RiskResult evaluateRoute(double expectedNetReturnPercent,
                         double volatilityPercent,
                         double liquidityScore,
                         double volatilityWeight,
                         double illiquidityWeight);
}
#endif
