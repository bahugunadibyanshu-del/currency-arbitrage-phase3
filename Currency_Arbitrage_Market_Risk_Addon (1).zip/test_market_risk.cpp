#include "market_risk.hpp"
#include <iostream>
#include <iomanip>
#include <vector>

int main() {
    // Simulated observations for demonstration; replace with real history.
    std::vector<double> rates = {
        1.0820, 1.0831, 1.0818, 1.0840, 1.0827, 1.0850
    };

    // Simulated bid, ask and market depth; not live exchange data.
    MarketRisk::LiquidityInput liquidity {
        1.0848, 1.0852, 250000.0, 100000.0
    };

    try {
        double volatility = MarketRisk::calculateVolatility(rates);
        double spread = MarketRisk::calculateSpreadPercent(
            liquidity.bid, liquidity.ask);
        double score = MarketRisk::calculateLiquidityScore(liquidity);

        const double expectedNetReturn = 1.80;
        const double volatilityWeight = 0.05;
        const double illiquidityWeight = 0.02;

        auto result = MarketRisk::evaluateRoute(
            expectedNetReturn, volatility, score,
            volatilityWeight, illiquidityWeight);

        std::cout << std::fixed << std::setprecision(4);
        std::cout << "MARKET RISK ANALYSIS (SIMULATED DATA)\n";
        std::cout << "Volatility:             " << volatility << "%\n";
        std::cout << "Bid-ask spread:         " << spread << "%\n";
        std::cout << "Liquidity score:        " << score << " / 100\n";
        std::cout << "Expected net return:    " << expectedNetReturn << "%\n";
        std::cout << "Risk penalty:           " << result.riskPenaltyPercent << "%\n";
        std::cout << "Risk-adjusted return:   "
                  << result.riskAdjustedReturnPercent << "%\n";
        std::cout << "Decision:               " << result.decision << "\n";
        std::cout << "Note: sample values are simulated, not live quotes.\n";
    } catch (const std::exception& error) {
        std::cerr << "Input error: " << error.what() << "\n";
        return 1;
    }
    return 0;
}
