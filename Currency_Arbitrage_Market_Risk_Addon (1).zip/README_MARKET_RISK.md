# Market Risk Analysis Add-on

These files are a separate, student-friendly C++ module. Add and test them before connecting them to the main arbitrage program.

## Volatility
Volatility measures how much an exchange rate changes over time. We calculate log returns:

`return = ln(current_rate / previous_rate)`

Then we calculate the sample standard deviation of those returns and express it as a percentage. The rates should be positive and sampled at consistent intervals.

## Liquidity
Liquidity describes how easily an amount can be exchanged without causing a large price movement. This example uses:
- Bid-ask spread: a smaller spread generally means lower conversion cost.
- Market depth: more available depth compared with the intended trade size generally means better liquidity.

The resulting 0-100 score is an educational model, not an official market rating.

## Risk-adjusted route score
`risk penalty = volatility weight * volatility + illiquidity weight * (100 - liquidity score)`

`risk-adjusted return = expected net return - risk penalty`

The weights are assumptions for experimentation. A positive result means the route can be reviewed further; it does not guarantee profit.

## Compile and run
```bash
g++ -std=c++17 -Wall -Wextra -pedantic market_risk.cpp test_market_risk.cpp -o market_risk_test
./market_risk_test
```

## Data limitation
The included observations, bid/ask and depth are simulated. A daily reference-rate API does not normally provide intraday history, executable venue bid/ask quotes or order-book depth. Real market-based scoring needs a data source that provides those fields.

## Suggested separate commits
```bash
git add market_risk.hpp market_risk.cpp
git commit -m "feat: add volatility and liquidity calculations"

git add test_market_risk.cpp
git commit -m "test: add market risk example"

git add README_MARKET_RISK.md
git commit -m "docs: explain market risk scoring"
```
Do not commit the compiled executable.
