#include "market_risk.hpp"
#include <cmath>
#include <stdexcept>
#include <algorithm>

namespace MarketRisk {
double calculateVolatility(const std::vector<double>& rates) {
    if (rates.size() < 3)
        throw std::invalid_argument("At least three observations are needed.");

    std::vector<double> returns;
    for (std::size_t i = 1; i < rates.size(); ++i) {
        if (rates[i] <= 0.0 || rates[i - 1] <= 0.0)
            throw std::invalid_argument("Rates must be positive.");
        returns.push_back(std::log(rates[i] / rates[i - 1]));
    }

    double mean = 0.0;
    for (double value : returns) mean += value;
    mean /= returns.size();

    double variance = 0.0;
    for (double value : returns) {
        double difference = value - mean;
        variance += difference * difference;
    }
    variance /= (returns.size() - 1);

    return std::sqrt(variance) * 100.0;
}

double calculateSpreadPercent(double bid, double ask) {
    if (bid <= 0.0 || ask < bid)
        throw std::invalid_argument("Invalid bid/ask prices.");
    double mid = (bid + ask) / 2.0;
    return ((ask - bid) / mid) * 100.0;
}

double calculateLiquidityScore(const LiquidityInput& input) {
    if (input.bid <= 0.0 || input.ask < input.bid ||
        input.marketDepth < 0.0 || input.requiredAmount <= 0.0)
        throw std::invalid_argument("Invalid liquidity input.");

    double spread = calculateSpreadPercent(input.bid, input.ask);
    double spreadScore = 100.0 / (1.0 + 20.0 * spread);
    double depthCoverage =
        std::min(input.marketDepth / input.requiredAmount, 1.0);
    double depthScore = depthCoverage * 100.0;

    // Educational weights: spread 60%, market depth 40%.
    return 0.60 * spreadScore + 0.40 * depthScore;
}

RiskResult evaluateRoute(double expectedNetReturnPercent,
                         double volatilityPercent,
                         double liquidityScore,
                         double volatilityWeight,
                         double illiquidityWeight) {
    if (volatilityPercent < 0.0 || liquidityScore < 0.0 ||
        liquidityScore > 100.0 || volatilityWeight < 0.0 ||
        illiquidityWeight < 0.0)
        throw std::invalid_argument("Risk inputs are outside valid ranges.");

    double penalty = volatilityWeight * volatilityPercent
                   + illiquidityWeight * (100.0 - liquidityScore);
    double adjustedReturn = expectedNetReturnPercent - penalty;

    return {volatilityPercent, liquidityScore, penalty, adjustedReturn,
            adjustedReturn > 0.0 ? "REVIEW ROUTE" : "AVOID ROUTE"};
}
}
