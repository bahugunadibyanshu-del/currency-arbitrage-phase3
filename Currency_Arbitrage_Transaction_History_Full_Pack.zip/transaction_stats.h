#ifndef TRANSACTION_STATS_H
#define TRANSACTION_STATS_H
#include "transaction_list.h"

typedef struct {
    int transactionCount;
    double totalInput;
    double totalFees;
} TransactionSummary;

TransactionSummary calculateSummary(const TransactionNode *head);

#endif
