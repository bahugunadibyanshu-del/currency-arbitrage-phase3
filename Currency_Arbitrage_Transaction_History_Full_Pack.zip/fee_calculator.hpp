#ifndef FEE_CALCULATOR_HPP
#define FEE_CALCULATOR_HPP

class FeeCalculator {
private:
    double feePercent;

public:
    explicit FeeCalculator(double fee);
    double calculate(double grossAmount) const;
    double getRate() const;
};

#endif
