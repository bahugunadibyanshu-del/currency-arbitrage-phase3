#include "csv_exporter.hpp"
#include <fstream>

bool CsvExporter::exportRecords(const std::vector<CsvTransaction>& records,
                                const std::string& filename) const {
    std::ofstream file(filename);
    if (!file)
        return false;

    file << "from,to,input_amount,rate,fee_percent,final_amount\n";
    for (const CsvTransaction& item : records) {
        file << item.from << ',' << item.to << ','
             << item.inputAmount << ',' << item.rate << ','
             << item.feePercent << ',' << item.finalAmount << '\n';
    }

    return file.good();
}
