#include "transaction_search.h"
#include <string.h>

/* Returns the number of records involving the requested currency. */
int searchCurrency(const TransactionNode *head, const char *currencyCode) {
    int matches = 0;

    while (head != NULL) {
        if (strcmp(head->data.from, currencyCode) == 0 ||
            strcmp(head->data.to, currencyCode) == 0) {
            matches++;
        }
        head = head->next;
    }

    return matches;
}
