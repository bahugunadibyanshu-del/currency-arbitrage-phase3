#include "transaction_list.h"
#include <stdio.h>
#include <stdlib.h>

void listInsert(TransactionNode **head, Transaction transaction) {
    TransactionNode *node = malloc(sizeof(TransactionNode));
    if (node == NULL) {
        fprintf(stderr, "Could not allocate transaction node.\n");
        return;
    }

    node->data = transaction;
    node->next = *head;
    *head = node;
}

void listDisplay(const TransactionNode *head) {
    const TransactionNode *current = head;
    int number = 1;

    printf("FULL IN-MEMORY HISTORY\n");
    while (current != NULL) {
        printf("%d) %s -> %s | input %.2f | final %.2f\n",
               number++, current->data.from, current->data.to,
               current->data.inputAmount, current->data.finalAmount);
        current = current->next;
    }

    if (number == 1)
        printf("No records available.\n");
}

void listFree(TransactionNode **head) {
    while (*head != NULL) {
        TransactionNode *oldNode = *head;
        *head = (*head)->next;
        free(oldNode);
    }
}
