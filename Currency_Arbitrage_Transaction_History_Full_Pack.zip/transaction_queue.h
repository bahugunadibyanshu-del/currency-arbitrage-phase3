#ifndef TRANSACTION_QUEUE_H
#define TRANSACTION_QUEUE_H
#include "transaction.h"

#define HISTORY_LIMIT 5

typedef struct {
    Transaction items[HISTORY_LIMIT];
    int front;
    int rear;
    int count;
} TransactionQueue;

void queueInit(TransactionQueue *queue);
void queueAdd(TransactionQueue *queue, Transaction transaction);
void queueDisplay(const TransactionQueue *queue);

#endif
