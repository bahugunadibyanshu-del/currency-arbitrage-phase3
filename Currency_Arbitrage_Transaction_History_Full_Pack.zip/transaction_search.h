#ifndef TRANSACTION_SEARCH_H
#define TRANSACTION_SEARCH_H
#include "transaction_list.h"

int searchCurrency(const TransactionNode *head, const char *currencyCode);

#endif
