#ifndef TRANSACTION_LIST_H
#define TRANSACTION_LIST_H
#include "transaction.h"

typedef struct TransactionNode {
    Transaction data;
    struct TransactionNode *next;
} TransactionNode;

void listInsert(TransactionNode **head, Transaction transaction);
void listDisplay(const TransactionNode *head);
void listFree(TransactionNode **head);

#endif
