#ifndef TRANSACTION_H
#define TRANSACTION_H

#define CURRENCY_CODE_SIZE 4

typedef struct {
    char from[CURRENCY_CODE_SIZE];
    char to[CURRENCY_CODE_SIZE];
    double inputAmount;
    double exchangeRate;
    double feePercent;
    double finalAmount;
} Transaction;

#endif
