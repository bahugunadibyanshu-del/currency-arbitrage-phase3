#!/bin/sh
set -eu

cc -std=c11 -Wall -Wextra -pedantic \
  transaction_queue.c transaction_list.c transaction_search.c \
  transaction_stats.c c_demo.c -o c_demo

c++ -std=c++17 -Wall -Wextra -pedantic \
  conversion_record.cpp fee_calculator.cpp csv_exporter.cpp cpp_demo.cpp \
  -o cpp_demo

echo "===== C: TRANSACTION HISTORY / DSA ====="
./c_demo

echo
echo "===== C++: RECEIPT AND CSV EXPORT / OOP ====="
./cpp_demo
