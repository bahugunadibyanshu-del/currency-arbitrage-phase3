#include <stddef.h>
#include "transaction_stats.h"

TransactionSummary calculateSummary(const TransactionNode *head) {
    TransactionSummary summary = {0, 0.0, 0.0};

    while (head != NULL) {
        double gross = head->data.inputAmount * head->data.exchangeRate;
        double fee = gross * head->data.feePercent / 100.0;

        summary.transactionCount++;
        summary.totalInput += head->data.inputAmount;
        summary.totalFees += fee;

        head = head->next;
    }

    return summary;
}
