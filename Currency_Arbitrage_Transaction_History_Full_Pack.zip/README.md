# Currency Conversion History & Receipt Module

This add-on introduces a small transaction-history feature for the currency-arbitrage project. It is separate from the existing arbitrage detector, so you can test it first and integrate it later.

## What is included

### C / Data Structures and Algorithms
- `transaction.h` — common transaction structure.
- `transaction_queue.h/.c` — circular queue that keeps the latest five conversions.
- `transaction_list.h/.c` — linked list for storing and displaying transaction records.
- `transaction_search.h/.c` — linear search by source or target currency.
- `transaction_stats.h/.c` — summary calculations such as total conversions and total fees.
- `c_demo.c` — demonstrates the C modules together.

### C++ / Object-Oriented Programming
- `conversion_record.hpp/.cpp` — class for a single conversion receipt.
- `fee_calculator.hpp/.cpp` — separate class for calculating a transaction fee.
- `csv_exporter.hpp/.cpp` — exports conversion records to a CSV file.
- `cpp_demo.cpp` — demonstrates the C++ classes.

## DSA concepts used
- **Circular queue:** retains the latest five conversions; enqueue is O(1).
- **Singly linked list:** stores a flexible number of records; inserting at the head is O(1).
- **Linear search:** finds records by currency code; O(n).
- **Structures and arrays:** store and process transaction information.

## OOP concepts used
- **Classes and objects:** `ConversionRecord`, `FeeCalculator`, `CsvExporter`.
- **Encapsulation:** transaction details are private inside the receipt class.
- **Constructors:** validate and initialize conversion details.
- **Composition:** the receipt uses a fee-calculation object.
- **File handling:** CSV exporter writes records for later inspection.

## Build and run on macOS

Run the C demo:

```bash
cc -std=c11 -Wall -Wextra -pedantic \
  transaction_queue.c transaction_list.c transaction_search.c \
  transaction_stats.c c_demo.c -o c_demo
./c_demo
```

Run the C++ demo:

```bash
c++ -std=c++17 -Wall -Wextra -pedantic \
  conversion_record.cpp fee_calculator.cpp csv_exporter.cpp cpp_demo.cpp \
  -o cpp_demo
./cpp_demo
```

Or run both using:

```bash
chmod +x run_all.sh
./run_all.sh
```

## Important data note

The sample exchange rates, amounts and fees are illustrative test data. This module records and reports conversions; it does not execute trades or prove real arbitrage profit. The queue and linked list are in-memory demonstrations. The CSV export is the persistent output in this add-on.

## Suggested meaningful Git commits

Make a commit after each working feature. Do not create empty commits or split one unchanged file into many artificial commits.

1. `feat: define reusable currency transaction structure`
2. `feat: add circular queue for recent conversions`
3. `feat: add linked list transaction history`
4. `feat: add currency based transaction search`
5. `feat: calculate transaction history summary`
6. `feat: add encapsulated conversion receipt class`
7. `feat: separate transaction fee calculation`
8. `feat: export conversion history to csv`
9. `test: add sample transaction history demo`
10. `docs: explain transaction history data structures`

## Suggested future integration

When the standalone tests pass, replace the sample transactions in `c_demo.c` and `cpp_demo.cpp` with conversion results produced by the main arbitrage program. Keep the history module separate from the algorithm that detects arbitrage cycles.
