#include "conversion_record.hpp"
#include <iostream>
#include <iomanip>
#include <stdexcept>

ConversionRecord::ConversionRecord(const std::string& source,
                                   const std::string& target,
                                   double amount,
                                   double rate,
                                   double feePercent)
    : sourceCurrency(source), targetCurrency(target),
      inputAmount(amount), exchangeRate(rate),
      feeCalculator(feePercent) {
    if (source.empty() || target.empty() || amount <= 0.0 || rate <= 0.0)
        throw std::invalid_argument("Invalid conversion details.");
}

double ConversionRecord::grossAmount() const {
    return inputAmount * exchangeRate;
}

double ConversionRecord::feeAmount() const {
    return feeCalculator.calculate(grossAmount());
}

double ConversionRecord::finalAmount() const {
    return grossAmount() - feeAmount();
}

void ConversionRecord::display() const {
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "CONVERSION RECEIPT\n"
              << inputAmount << " " << sourceCurrency
              << " -> " << targetCurrency << "\n"
              << "Rate: " << exchangeRate << "\n"
              << "Gross amount: " << grossAmount() << "\n"
              << "Fee (" << feeCalculator.getRate() << "%): "
              << feeAmount() << "\n"
              << "Final amount: " << finalAmount() << "\n";
}
