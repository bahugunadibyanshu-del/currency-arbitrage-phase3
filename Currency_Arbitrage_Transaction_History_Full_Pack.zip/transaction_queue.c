#include "transaction_queue.h"
#include <stdio.h>

void queueInit(TransactionQueue *queue) {
    queue->front = 0;
    queue->rear = -1;
    queue->count = 0;
}

void queueAdd(TransactionQueue *queue, Transaction transaction) {
    if (queue->count == HISTORY_LIMIT) {
        queue->front = (queue->front + 1) % HISTORY_LIMIT;
        queue->count--;
    }

    queue->rear = (queue->rear + 1) % HISTORY_LIMIT;
    queue->items[queue->rear] = transaction;
    queue->count++;
}

void queueDisplay(const TransactionQueue *queue) {
    printf("RECENT CONVERSIONS (oldest to newest)\n");

    for (int i = 0; i < queue->count; i++) {
        int index = (queue->front + i) % HISTORY_LIMIT;
        const Transaction *item = &queue->items[index];

        printf("%d) %.2f %s -> %.2f %s\n",
               i + 1, item->inputAmount, item->from,
               item->finalAmount, item->to);
    }

    if (queue->count == 0)
        printf("No records available.\n");
}
