#ifndef CSV_EXPORTER_HPP
#define CSV_EXPORTER_HPP
#include <string>
#include <vector>

struct CsvTransaction {
    std::string from;
    std::string to;
    double inputAmount;
    double rate;
    double feePercent;
    double finalAmount;
};

class CsvExporter {
public:
    bool exportRecords(const std::vector<CsvTransaction>& records,
                       const std::string& filename) const;
};

#endif
