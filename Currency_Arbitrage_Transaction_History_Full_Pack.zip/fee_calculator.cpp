#include "fee_calculator.hpp"
#include <stdexcept>

FeeCalculator::FeeCalculator(double fee) : feePercent(fee) {
    if (fee < 0.0 || fee >= 100.0)
        throw std::invalid_argument("Fee must be between 0 and 100 percent.");
}

double FeeCalculator::calculate(double grossAmount) const {
    if (grossAmount < 0.0)
        throw std::invalid_argument("Amount cannot be negative.");

    return grossAmount * feePercent / 100.0;
}

double FeeCalculator::getRate() const {
    return feePercent;
}
