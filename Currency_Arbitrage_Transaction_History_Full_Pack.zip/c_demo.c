#include "transaction_queue.h"
#include "transaction_list.h"
#include "transaction_search.h"
#include "transaction_stats.h"
#include <stdio.h>

static Transaction makeTransaction(const char *from, const char *to,
                                    double amount, double rate, double fee) {
    Transaction item = {{0}, {0}, amount, rate, fee, 0.0};
    snprintf(item.from, CURRENCY_CODE_SIZE, "%s", from);
    snprintf(item.to, CURRENCY_CODE_SIZE, "%s", to);

    double gross = amount * rate;
    item.finalAmount = gross - (gross * fee / 100.0);
    return item;
}

int main(void) {
    Transaction sample[] = {
        makeTransaction("USD", "EUR", 100.0, 0.92, 0.20),
        makeTransaction("EUR", "GBP", 200.0, 0.85, 0.20),
        makeTransaction("GBP", "INR", 50.0, 104.0, 0.20),
        makeTransaction("USD", "INR", 75.0, 83.0, 0.20),
        makeTransaction("EUR", "JPY", 120.0, 160.0, 0.20),
        makeTransaction("INR", "USD", 5000.0, 0.012, 0.20)
    };

    TransactionQueue recent;
    queueInit(&recent);

    TransactionNode *history = NULL;
    int count = (int)(sizeof(sample) / sizeof(sample[0]));

    for (int i = 0; i < count; i++) {
        queueAdd(&recent, sample[i]);
        listInsert(&history, sample[i]);
    }

    queueDisplay(&recent);
    printf("\n");
    listDisplay(history);

    printf("\nRecords involving EUR: %d\n",
           searchCurrency(history, "EUR"));

    TransactionSummary summary = calculateSummary(history);
    printf("Total records: %d\n", summary.transactionCount);
    printf("Total input amounts: %.2f (mixed currencies; count only)\n",
           summary.totalInput);
    printf("Calculated fees: %.4f (mixed currencies; illustrative)\n",
           summary.totalFees);

    listFree(&history);
    return 0;
}
