#ifndef CONVERSION_RECORD_HPP
#define CONVERSION_RECORD_HPP

#include <string>
#include "fee_calculator.hpp"

class ConversionRecord {
private:
    std::string sourceCurrency;
    std::string targetCurrency;
    double inputAmount;
    double exchangeRate;
    FeeCalculator feeCalculator;

public:
    ConversionRecord(const std::string& source,
                     const std::string& target,
                     double amount,
                     double rate,
                     double feePercent);

    double grossAmount() const;
    double feeAmount() const;
    double finalAmount() const;
    void display() const;
};

#endif
