#include "conversion_record.hpp"
#include "csv_exporter.hpp"
#include <iostream>
#include <vector>

int main() {
    try {
        ConversionRecord receipt("USD", "EUR", 1000.0, 0.92, 0.20);
        receipt.display();

        std::vector<CsvTransaction> records = {
            {"USD", "EUR", 1000.0, 0.92, 0.20, receipt.finalAmount()},
            {"EUR", "GBP", 200.0, 0.85, 0.20, 169.66}
        };

        CsvExporter exporter;
        if (exporter.exportRecords(records, "conversion_history.csv"))
            std::cout << "History exported to conversion_history.csv\n";
        else
            std::cerr << "Could not export CSV file.\n";
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }

    std::cout << "Note: sample conversion values are illustrative.\n";
    return 0;
}
